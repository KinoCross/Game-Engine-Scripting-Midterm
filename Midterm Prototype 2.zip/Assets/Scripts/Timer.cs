﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    public float courseTime = 0f;
    public Text uitext;

    // Start is called before the first frame update
    void Start()
    {
        uitext = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        courseTime += Time.deltaTime;
        uitext.text = "Time: " + ((int)courseTime).ToString();
    }
}
